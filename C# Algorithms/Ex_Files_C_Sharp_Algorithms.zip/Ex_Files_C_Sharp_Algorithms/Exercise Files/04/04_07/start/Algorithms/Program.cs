﻿using System;
using System.Collections.Generic;

namespace Algorithms {
    class Program {
        static void printNextGreaterElement(int[] arr) {

        }

        static void Main(string[] args) {
            int[] arr = new int[] {15, 8, 4, 10};
            int[] arr2 = new int[] {2};
            int[] arr3 = new int[] {2, 3};
            int[] arr4 = new int[] {};

            printNextGreaterElement(arr);
            printNextGreaterElement(arr2);
            printNextGreaterElement(arr3);
            printNextGreaterElement(arr4);
        }
    }
}