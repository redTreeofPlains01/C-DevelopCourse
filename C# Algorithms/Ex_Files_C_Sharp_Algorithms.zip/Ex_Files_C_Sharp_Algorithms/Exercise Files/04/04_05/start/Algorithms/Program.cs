﻿using System;

namespace Algorithms {
    class Program {

        static void Main(string[] args) {

        }
    }
}