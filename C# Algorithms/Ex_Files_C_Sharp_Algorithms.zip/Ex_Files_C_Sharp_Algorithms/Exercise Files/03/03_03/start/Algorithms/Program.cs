﻿using System;

namespace Algorithms {
    class CustomLinkedList {

        Node head;

        public class Node {
            public int data;
            public Node next;

            public Node(int d) { data = d; }
        }

        static void Main(string[] args) {

        }
    }
}