﻿using System;

namespace Algorithms {
    class Program {

        static Boolean LinearSearch(int[] input, int n) {
            return false;
        }

        static void Main(string[] args) {
            int[] arr = {1, 2, 3, 4, 5, 6 };
            LinearSearch(arr, 4);
        }
    }
}