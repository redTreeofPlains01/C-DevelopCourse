﻿using System;

namespace Algorithms {
    class Program {

        static Boolean BinarySearch(int[] inputArray, int item) {
            return false;
        }

        static void Main(string[] args) {
            int[] arr = {1, 2, 3, 4, 5, 6 };
        }
    }
}